import React, { useState, useEffect } from "react";
import "./ResponsiveComponent.css";

const ResponsiveComponent = () => {
  const [isMobile, setIsMobile] = useState(window.innerWidth < 768);

  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth < 768);
    };

    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  return (
    <div className={container ${isMobile ? "vertical" : "horizontal"}}>
      <div className="item">🛒 Product 1</div>
      <div className="item">💳 Product 2</div>
      <div className="item">📦 Product 3</div>
    </div>
  );
};

export default ResponsiveComponent;